package com.example.android.musicplayer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class PopSongs extends AppCompatActivity {

    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_songs);
        setonBackOnButton();

        // Create an array of Pop Songs

        class AndroidPop {

            public AndroidPop(PopSongs popSongs) {
            }

            public AndroidPop(String popSongs, String duration) {

            }

            void f() {
                int i;
                i = 0;
            }
        }

        ArrayList<AndroidPop> androidPopArrayList = new ArrayList<AndroidPop>();
        androidPopArrayList.add(new AndroidPop("Zayn dusk till done", "3:40"));
        androidPopArrayList.add(new AndroidPop("", "3:33"));
        androidPopArrayList.add(new AndroidPop("", "3:35"));
        androidPopArrayList.add(new AndroidPop("", "2:55"));
        androidPopArrayList.add(new AndroidPop("", "3:30"));

        AndroidPop androidPop = new AndroidPop(this);
        {

            // Get a reference to the ListView, and attach the adapter to the listView.

            ListView listView = (ListView) findViewById(R.id.listview_);

            listView.setAdapter((ListAdapter) listView);
        }
    }


    public void setonBackOnButton() {

        final Context onBack = this;

        back =(Button) findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(onBack, MainActivity.class);
                startActivity(intent);

            }
        });

    }
}
